MISE À JOUR ISIDORE AI — CONTEXTE DES CONVERSATIONS

Fichiers inclus :
- server.mjs : version modifiée pour recevoir et transmettre l’historique récent à Gemini.
- update-index.py : script qui modifie uniquement les textes du nom et la requête API dans le index.html existant.

IMPORTANT :
1. Faites une copie de sauvegarde de server.mjs et index.html avant remplacement.
2. Remplacez server.mjs par celui fourni.
3. Placez update-index.py dans le dossier du projet qui contient index.html, puis exécutez :
   python update-index.py
4. Vérifiez les changements dans index.html avant de faire un commit.
5. Faites un commit sur GitHub. Render déploiera ensuite selon la configuration du service.
6. Ne partagez jamais la valeur de GEMINI_API_KEY et ne la mettez pas dans les fichiers du dépôt.

Cette version transmet jusqu’à 16 messages antérieurs (texte uniquement) au modèle. Les images antérieures ne sont pas envoyées comme éléments de mémoire. L’historique persiste toujours uniquement dans le stockage local du navigateur; une mémoire synchronisée entre appareils ou entre comptes nécessite une base de données et une identification utilisateur, ce qui n’est pas inclus ici.

Le fichier server.mjs a passé une vérification syntaxique avec node --check. Il n’a pas été déployé ni testé en direct avec la clé API du propriétaire.
